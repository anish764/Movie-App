package com.example.movieinfo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
